package com.service;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JackService {
	
	public String getValue()
	{
		
		String val = "{ \"me\" : \"Sathish\"}";
		String ret = null;
		
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			
		 ret = objectMapper.writeValueAsString(val);
			
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
		return ret;		
	}
	
	public String dispValue(String req)
	{
		
		
		ObjectMapper objectMapper = new ObjectMapper();

		try {				
		
			JsonNode node = objectMapper.readValue(req, JsonNode.class);			
			JsonNode nameNode = node.get("name");
			String name = nameNode.asText();
			System.out.println("name = " + name);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return req;
		
	}
	
	

	/*public static void main(String[] args) {

		String carJson = "{ \"brand\" : \"Mercedes\", \"doors\" : 5,"
				+ "  \"owners\" : [\"John\", \"Jack\", \"Jill\"],"
				+ "  \"nestedObject\" : { \"field\" : \"value\" } }";

		ObjectMapper objectMapper = new ObjectMapper();

		try {

			JsonNode node = objectMapper.readValue(carJson, JsonNode.class);

			JsonNode brandNode = node.get("brand");
			String brand = brandNode.asText();
			System.out.println("brand = " + brand);

			JsonNode doorsNode = node.get("doors");
			int doors = doorsNode.asInt();
			System.out.println("doors = " + doors);

			JsonNode array = node.get("owners");
			JsonNode jsonNode = array.get(0);
			String john = jsonNode.asText();
			System.out.println("john  = " + john);

			JsonNode child = node.get("nestedObject");
			JsonNode childField = child.get("field");
			String field = childField.asText();
			System.out.println("field = " + field);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}*/

}
