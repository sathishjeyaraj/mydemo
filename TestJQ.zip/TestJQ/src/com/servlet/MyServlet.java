package com.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
	
		String name = request.getParameter("user");
		String pass = request.getParameter("pass");

		if (pass.equals("1234")) {
			Cookie ck = new Cookie("username", name);
			response.addCookie(ck);
			response.sendRedirect("First");
		}
	}
}