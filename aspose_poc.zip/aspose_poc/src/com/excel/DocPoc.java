package com.excel;

import java.io.File;
import java.io.FileInputStream;
import java.util.regex.Pattern;

import com.aspose.words.CompositeNode;
import com.aspose.words.Document;
import com.aspose.words.IReplacingCallback;
import com.aspose.words.ImportFormatMode;
import com.aspose.words.Node;
import com.aspose.words.NodeImporter;
import com.aspose.words.NodeType;
import com.aspose.words.Paragraph;
import com.aspose.words.ReplaceAction;
import com.aspose.words.ReplacingArgs;
import com.aspose.words.Section;

public class DocPoc {

	static String dataDir = "D:" + File.separator + "JSathish" + File.separator
			+ "poc_chart" + File.separator;
	
	public static void main(String[] args) throws Exception {

		FileInputStream licenseFile = new FileInputStream(
				"D:\\All SME Project\\SME Only UAT\\Standalone\\lib\\Aspose.Total.Java.lic");

		new com.aspose.words.License().setLicense(licenseFile);			
		
		Document mainDoc = new Document(dataDir + "12 10 16_V3_CRISIL-LDD New REPORT.docx");
		
		mainDoc.getRange().replace(Pattern.compile("\\[INSERT_DOCUMENT\\]"), new InsertDocumentAtReplaceHandler(), false);
		
		mainDoc.save(dataDir + "InsertDocumentAtReplace.doc");
		
		System.out.println("Done Done");

	}

	private static class InsertDocumentAtReplaceHandler implements IReplacingCallback {
		
		public int replacing(ReplacingArgs e) throws Exception {

			Document subDoc = new Document(dataDir + "Industry Outlook - SME Report - Dairy and dairy products.doc");

			// Insert a document after the paragraph, containing the match text.
			Paragraph para = (Paragraph) e.getMatchNode().getParentNode();			
			
			insertDocument(para, subDoc);

			// Remove the paragraph with the match text.
			para.remove();

			return ReplaceAction.SKIP;
		}
	}

	public static void insertDocument(Node insertAfterNode, Document srcDoc)
			throws Exception {

		if ((insertAfterNode.getNodeType() != NodeType.PARAGRAPH)
				& (insertAfterNode.getNodeType() != NodeType.TABLE)) {
			throw new IllegalArgumentException(
					"The destination node should be either a paragraph or table.");
		}

		CompositeNode dstStory = insertAfterNode.getParentNode();

		NodeImporter importer = new NodeImporter(srcDoc,
				insertAfterNode.getDocument(),
				ImportFormatMode.KEEP_SOURCE_FORMATTING);

		for (Section srcSection : srcDoc.getSections()) {

			for (Node srcNode : (Iterable<Node>) srcSection.getBody()) {

				if (srcNode.getNodeType() == (NodeType.PARAGRAPH)) {
					Paragraph para = (Paragraph) srcNode;
					if (para.isEndOfSection() && !para.hasChildNodes())
						continue;
				}

				Node newNode = importer.importNode(srcNode, true);

				dstStory.insertAfter(newNode, insertAfterNode);
				insertAfterNode = newNode;
			}
		}
	}
}
