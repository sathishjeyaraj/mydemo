package com.excel;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;

import com.aspose.cells.Cell;
import com.aspose.cells.Chart;
import com.aspose.cells.ImageFormat;
import com.aspose.cells.ImageOrPrintOptions;
import com.aspose.cells.License;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;

public class ExcelToWord {

	public static void main(String[] args) throws Exception {

		FileInputStream licenseFile = new FileInputStream(
				"D:\\All SME Project\\SME Only UAT\\Standalone\\lib\\Aspose.Total.Java.lic");
		
		License license = new License();
		
		license.setLicense(licenseFile);	
		
		String path = "D:" + File.separator + "JSathish" + File.separator + "poc_chart" + File.separator ;
		

		Workbook workbook = new Workbook(path + "Book1.xlsx");

		Cell cell = workbook.getWorksheets().get(0).getCells().get("C5");

		cell.putValue(Integer.parseInt("250"));

		workbook.save(path + "NoteBook.xlsx");

		//===================			
		
		Workbook book = new Workbook(path + "NoteBook.xlsx");
		
		Worksheet sheet = book.getWorksheets().get(0);
		
		ImageOrPrintOptions imgOpts = new ImageOrPrintOptions();
		
		imgOpts.setImageFormat(ImageFormat.getPng());
		
		ByteArrayOutputStream fos = null;
		
		for (int i = 0; i < sheet.getCharts().getCount(); i++) {
			
			Chart ch = sheet.getCharts().get(i);
			
			fos = new ByteArrayOutputStream();
			
			ch.toImage(fos, imgOpts);

			ch.toImage(path + "MyChartImage.png", imgOpts);			
		}		
		
		byte[] data = fos.toByteArray();
		
		ByteArrayInputStream input = new ByteArrayInputStream(data);
		
        BufferedImage image = ImageIO.read(input);	
        
      //====================
        
        Document doc = new Document();

		DocumentBuilder builder = new DocumentBuilder(doc);	

		builder.insertImage(image);

		doc.save(path + "noteImage.docx");

	}

}
