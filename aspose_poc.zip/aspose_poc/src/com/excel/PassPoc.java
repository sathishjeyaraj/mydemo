package com.excel;

import java.io.File;
import java.io.FileInputStream;

import com.aspose.words.Document;
import com.aspose.words.ProtectionType;

public class PassPoc {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		FileInputStream licenseFile = new FileInputStream(
				"D:\\All SME Project\\SME Only UAT\\Standalone\\lib\\Aspose.Total.Java.lic");

		new com.aspose.words.License().setLicense(licenseFile);
		
		int flag = 0;

		String path = "D:" + File.separator + "JSathish" + File.separator
				+ "poc_chart" + File.separator;

		Document doc = new Document(path + "test.docx");

		if (flag == 0) {
			System.out.println("protect");
			doc.unprotect();
			doc.protect(ProtectionType.ALLOW_ONLY_FORM_FIELDS, "1235");

		} else {
			System.out.println("unprotect");
			doc.unprotect();
		}

		doc.save(path + "Pass.docx");

	}

}
