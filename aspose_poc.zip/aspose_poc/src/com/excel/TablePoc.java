package com.excel;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import com.aspose.words.Cell;
import com.aspose.words.CellCollection;
import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.NodeType;
import com.aspose.words.Row;
import com.aspose.words.RowCollection;
import com.aspose.words.Table;

public class TablePoc {

	public static void main(String[] args) throws Exception {

		FileInputStream licenseFile = new FileInputStream(
				"D:\\All SME Project\\SME Only UAT\\Standalone\\lib\\Aspose.Total.Java.lic");

		new com.aspose.words.License().setLicense(licenseFile);

		// License license = new License();
		// license.setLicense(licenseFile);

		String path = "D:" + File.separator + "JSathish" + File.separator
				+ "poc_chart" + File.separator;

		Document doc = new Document();

		DocumentBuilder builder = new DocumentBuilder(doc);

		builder.startTable();
		builder.insertCell();
		builder.write("Row 1, Cell 1");

		builder.insertCell();
		builder.write("Row 1, Cell 2");
		builder.endRow();

		builder.insertCell();
		builder.write("Row 2, Cell 1");

		builder.insertCell();
		builder.write("Row 2, Cell 2");
		builder.endRow();

		builder.endTable();

		doc.save(path + "dynamicTable.doc");

		// ==============Traversing column

		Document doc2 = new Document(path + "dynamicTable.doc");

		DocumentBuilder builder2 = new DocumentBuilder(doc2);

		// Get the first table in the document.
		Table table = (Table) doc2.getChild(NodeType.TABLE, 0, true);

		RowCollection rows = table.getRows();

		Row row = rows.get(1);

		CellCollection cells = row.getCells();

		Cell c = cells.get(1);

		c.getFirstParagraph().getChildNodes().clear();

		builder2.moveTo(c.getFirstParagraph());

		builder2.writeln("changed".trim());

		System.out.println(c.getText().trim());

		doc2.save(path + "modifyTable.doc");

		// ===============adding new row 

		Document doc3 = new Document(path + "modifyTable.doc");			
	
		Table table3 = (Table) doc3.getChild(NodeType.TABLE, 0, true);

		Row clonedRow = (Row) table3.getLastRow().deepClone(true);

		Iterator newcalls = clonedRow.getCells().iterator();

		while (newcalls.hasNext()) {
			Cell ic = (Cell) newcalls.next();
			ic.getFirstParagraph().getChildNodes().clear();
		}

		table3.appendChild(clonedRow);
		
		doc3.save(path + "rowadd.doc");
		
		
		

	}

}
