package com.cust;

import java.util.List;
import java.util.Map;

import com.aspose.words.IMailMergeDataSource;

public class CustomMailMerge implements IMailMergeDataSource {

	private List<Map<String, String>> tempdataListMap;
	private int mRecordIndex;
	private String docTableName;
	private String[] docMergeFieldNames;

	public CustomMailMerge(String docTableName,List<Map<String, String>> dataListMap,String[] docMergeFieldNames ) {
		tempdataListMap = dataListMap;
		this.docTableName = docTableName;
		this.docMergeFieldNames = docMergeFieldNames;
		// When the data source is initialized, it must be positioned before the
		// first record.
		mRecordIndex = -1;
		
		System.out.println("Init");
	}

	@Override
	public String getTableName() throws Exception {
		System.out.println("TableName");
		return docTableName;
	}

	/// Aspose.Words calls this method to get a value for every data field.
	@Override
	public boolean getValue(String fieldName, Object[] fieldValue)
			throws Exception {

		boolean flag = false;
		Map<String, String> recMap = tempdataListMap.get(mRecordIndex);
		System.out.println("record position:" + mRecordIndex);
		
		for (String key : docMergeFieldNames) {
			
			if (fieldName.equals(key)) {
				fieldValue[0] = recMap.get(key);
				flag = true;
				System.out.println("Key:" + key + " " + "value:" + recMap.get(key));
			}
		}
		System.out.println(flag);

		return flag;

	}

	// A standard implementation for moving to a next record in a collection.
	@Override
	public boolean moveNext() throws Exception {
		System.out.println("Move");
		if (!IsEof())
			mRecordIndex++;

		return (!IsEof());
	}

	private boolean IsEof() {
		return (mRecordIndex >= tempdataListMap.size());
	}

	@Override
	public IMailMergeDataSource getChildDataSource(String arg0)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
