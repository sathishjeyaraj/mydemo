package com.cust;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.aspose.words.Document;
import com.aspose.words.License;

public class MailMergeMain {

	public static void main(String[] args) throws Exception { 
		FileInputStream licenseFile = new FileInputStream(
				"D:\\All SME Project\\SME Only UAT\\Standalone\\lib\\Aspose.Total.Java.lic");
		License license = new License();
		license.setLicense(licenseFile);
		
		//List<Customer> customers = new ArrayList<Customer>();
	    //customers.add(new Customer("Thomas W Hardy", "120 Hanover Sq., London"));
	    //customers.add(new Customer("Paolo Z Accorti", "Via Monte Bianco 34, Torino"));	
		
		String[] docMergeFieldNames = "Exopenstock,Exnonmoveopen,Excasealloc,Excaseexect,Exclosestock,Exnonmoveclose,Execdftrptsnt,Execfnlrptsnt,nsicopenstock,nsiccaseadd,nsicinvoice,nsicclosestock,feeopenbal,feeadd,feeclear,feeclosebal"
				.split(",");

		List<Map<String, String>> customerListMap = new ArrayList<Map<String, String>>();

		//for (Customer cust : customers) {	    

			Map<String, String> map = new LinkedHashMap<String, String>();
			map.put("Exopenstock", "Exopenstock");
			map.put("Exnonmoveopen", "Exnonmoveopen");
			map.put("Excasealloc", "Excasealloc");
			map.put("Excaseexect", "Excaseexect");
			map.put("Exclosestock", "Exclosestock");
			map.put("Exnonmoveclose", "Exnonmoveclose");
			map.put("Execdftrptsnt", "Execdftrptsnt");
			map.put("Execfnlrptsnt", "Execfnlrptsnt");				
			//====			
			map.put("nsicopenstock", "nsicopenstock");		
			map.put("nsiccaseadd", "nsiccaseadd");		
			map.put("nsicinvoice", "nsicinvoice");		
			map.put("nsicclosestock", "nsicclosestock");			
			//====			
			map.put("feeopenbal", "feeopenbal");		
			map.put("feeadd", "feeadd");		
			map.put("feeclear", "feeclear");		
			//map.put("feeclosebal", "feeclosebal");
			customerListMap.add(map);
			
						
		//}	        
			
		StringBuffer buf = new StringBuffer();

		for (Map<String, String> m : customerListMap) {
			
			Set<String> s = m.keySet();

			for (String key : s) {
				System.out.println(key+",");				
			}

		}
			
	    	
		CustomMailMerge customMailMergeData = new CustomMailMerge("Customer", customerListMap, docMergeFieldNames);

		Document doc = new Document("D:" + File.separator + "JSathish"+ File.separator + "MergeDemo.doc");
						
		//doc.getMailMerge().execute(new String[] { "to","who" }, new Object[] { "Sathish","Subi" });	
		doc.getMailMerge().executeWithRegions(customMailMergeData);
		
		doc.save("D:" + File.separator + "JSathish" + File.separator+ "MergeDemo2.doc");

	}

}
