package com.keypair;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;

import org.apache.commons.ssl.PKCS8Key;



public class TestSSL {
	
	
	
	public PrivateKey getPrivate() throws Exception {
		
		
		//FileInputStream in = new FileInputStream( "/path/to/pkcs8_private_key.der" );
		File file = new File("D:\\Davis\\keys\\rsakey1024.txt");			
		byte[] keyBytes = new byte[(int) file.length()];
		FileInputStream fis = new FileInputStream(file);
		fis.read(keyBytes); 
		fis.close();	

		// If the provided InputStream is encrypted, we need a password to decrypt
		// it. If the InputStream is not encrypted, then the password is ignored
		// (can be null).  The InputStream can be DER (raw ASN.1) or PEM (base64).
		PKCS8Key pkcs8 = new PKCS8Key(keyBytes,null);

		// If an unencrypted PKCS8 key was provided, then this actually returns
		// exactly what was originally passed in (with no changes).  If an OpenSSL
		// key was provided, it gets reformatted as PKCS #8 first, and so these
		// bytes will still be PKCS #8, not OpenSSL.
		byte[] decrypted = pkcs8.getDecryptedBytes();
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec( decrypted );

		// A Java PrivateKey object is born.
		PrivateKey pk = null;
		if ( pkcs8.isDSA() )
		{
		  pk = KeyFactory.getInstance( "DSA" ).generatePrivate( spec );
		}
		else if ( pkcs8.isRSA() )
		{
		  pk = KeyFactory.getInstance( "RSA" ).generatePrivate( spec );
		}

		return pk = pkcs8.getPrivateKey();
	}
	
	public static void main(String[] args) throws Exception {
		
		TestSSL e = new TestSSL();
		System.out.print(e.getPrivate());
	}
	

}
