package dwr;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.ssl.PKCS8Key;

public class EncrypDecryp {
	
	private Cipher cipher;
	
		public PrivateKey getPrivate() throws Exception {
			//byte[] keyBytes = Files.readAllBytes(new File(filename).toPath());
			
			File file = new File("D:\\Davis\\keys\\privateKey");			
			byte[] keyBytes = new byte[(int) file.length()];
			FileInputStream fis = new FileInputStream(file);
			fis.read(keyBytes); 
			fis.close();
			
			PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance("RSA");
			return kf.generatePrivate(spec);
		}
		
		public PublicKey getPublic() throws Exception {
			//byte[] keyBytes = Files.readAllBytes(new File(filename).toPath());
			
			File file = new File("D:\\Davis\\keys\\publicKey");			
			byte[] keyBytes = new byte[(int) file.length()];
			FileInputStream fis = new FileInputStream(file);
			fis.read(keyBytes); 
			fis.close();
			
			X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance("RSA");
			return kf.generatePublic(spec);
		}
		

	public String encryptText(String msg, PublicKey key)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			UnsupportedEncodingException, IllegalBlockSizeException,
			BadPaddingException, InvalidKeyException {
		
		this.cipher = Cipher.getInstance("RSA");
		this.cipher.init(Cipher.ENCRYPT_MODE, key);
		return Base64.encodeBase64String(cipher.doFinal(msg.getBytes("UTF-8")));
	}

	public String decryptText(String msg, PrivateKey key)
			throws InvalidKeyException, UnsupportedEncodingException,
			IllegalBlockSizeException, BadPaddingException,
			NoSuchAlgorithmException, NoSuchPaddingException {

		this.cipher = Cipher.getInstance("RSA");
		this.cipher.init(Cipher.DECRYPT_MODE, key);
		return new String(cipher.doFinal(Base64.decodeBase64(msg)), "UTF-8");
	}

   //=====	
	
	public PrivateKey getSSLPrivate() throws Exception {
		FileInputStream in = new FileInputStream("D:\\Davis\\keys\\rsa_1024_priv.pem");
		PKCS8Key pkcs8 = new PKCS8Key(in, null);
		byte[] decrypted = pkcs8.getDecryptedBytes();
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(decrypted);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		return kf.generatePrivate(spec);
	}
	
	@SuppressWarnings("resource")
	public String getSSLPubkey() throws Exception {

		StringBuffer buf = new StringBuffer();		 	
		String line;
		BufferedReader br = new BufferedReader(new FileReader("D:\\Davis\\keys\\rsa_1024_pub.pem"));
		while ((line = br.readLine()) != null) {
			buf.append(line);
		}
		System.out.println(buf.toString());		
		return buf.toString();
	}	
	
 //======
	
	public String getEncData(String pass) {

		System.out.println("pass::"+pass);
		String enc = null;
		
		try {

			enc = encryptText(pass, getPublic());
			
		System.out.println("enc::"+enc);
		} catch (InvalidKeyException e) {			
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {			
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {			
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {			
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {			
			e.printStackTrace();
		} catch (BadPaddingException e) {			
			e.printStackTrace();
		} catch (Exception e) {			
			e.printStackTrace();
		}

		return enc;
	}
	
	public String getDecrypData(String pass) {
		
		String enc = null;
		
		try {

			enc = decryptText(pass, getSSLPrivate());			
		
		} catch (InvalidKeyException e) {			
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {			
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {			
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {			
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {			
			e.printStackTrace();
		} catch (BadPaddingException e) {			
			e.printStackTrace();
		} catch (Exception e) {			
			e.printStackTrace();
		}

		return enc;
	}
	
	
	
	
	
	public static void main(String[] args) throws Exception { 
		/*EncrypDecryp ac = new EncrypDecryp();
		//PrivateKey privateKey = ac.getSSLPrivate("KeyPair/rsakey1024.txt");
		String encmsg = "Q8XR/TUp0fcbNZl5yYbYqemKP+CQj37GakyXzYaTR1fLvQqabDc1yZ1LkLoIOp8gxlvWon4bjjzsiMFD7oJBb5qFv2Heb44g0pg342PLRPv1efvwVsF8AZRQxMF46WI1soWC9/QzbtLft2OwBHs6rBqc3JZNdTpGCXMIe5J3T3U=";		
		String decrypted_msg = ac.decryptText(encmsg, privateKey);		
		System.out.println(decrypted_msg);
		*/
		//ac.getSSLPubkey();
	}
	
	
}
