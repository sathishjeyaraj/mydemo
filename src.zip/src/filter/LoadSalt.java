package filter;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.concurrent.TimeUnit;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.RandomStringUtils;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

public class LoadSalt implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
 throws IOException, ServletException {
		
		HttpServletRequest httpReq = (HttpServletRequest) request;
		
		@SuppressWarnings("unchecked")
		Cache<String, Boolean> csrfPreventionSaltCache = (Cache<String, Boolean>) httpReq.getSession().getAttribute("csrfPreventionSaltCache");

		if (csrfPreventionSaltCache == null) {
			
			csrfPreventionSaltCache = CacheBuilder.newBuilder().maximumSize(5000).expireAfterWrite(20, TimeUnit.MINUTES).build();

			httpReq.getSession().setAttribute("csrfPreventionSaltCache",csrfPreventionSaltCache);
		}
		
		String salt = RandomStringUtils.random(20, 0, 0, true, true, null, new SecureRandom());
		
		csrfPreventionSaltCache.put(salt, Boolean.TRUE);
		
		httpReq.setAttribute("csrfPreventionSalt", salt);
		
		System.out.println("Added salty value >>>" + salt);

		chain.doFilter(request, response);
	}

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
}