package test;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import dwr.EncrypDecryp;

public class TestAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		Logger Log = Logger.getLogger(TestAction.class.getName());

		//Log.info("ContextPath:" + request.getContextPath());
		///Log.info("ServletPath:" + request.getServletPath());
		//Log.info("QueryString:" + request.getQueryString());
		//Log.info("RequestURL:" + request.getRequestURL());

		// String
		// url=request.getContextPath()+request.getServletPath()+"?"+request.getQueryString();

		String user = request.getParameter("user");		
		String pass = request.getParameter("trans");

		Log.info("========================Server Side encrypt value=========================");		
		Log.info("username"+":: " + user);
		Log.info("Encryp Password"+":: " + pass);	
		Log.info("=============================================================");
		
		EncrypDecryp rsa = new EncrypDecryp();
		String decrpPass = rsa.getDecrypData(pass);
		Log.info("===========================Decryptvalue=================================");
		Log.info("Decryp Password" + ":: " + decrpPass);		
		Log.info("========================================================================");
		
	   return mapping.findForward("success");
		
	}

}
